
  # Budgeting Tool Website

  This is a code bundle for Budgeting Tool Website. The original project is available at https://www.figma.com/design/Fk0acyKBf3H0QJeQNMPgYo/Budgeting-Tool-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  